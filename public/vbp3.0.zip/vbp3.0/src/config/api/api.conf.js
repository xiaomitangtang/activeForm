export const demo = {
  test: "/api/test" // 测试请求路径
};
