/**
 * @description 各个服务模块统一仓储
 */
import demo from "@/fetch/demo-api";
export const apistore = {
  demo
};
