import En from "@/languages/en";
import Zh from "@/languages/zh";
const languages = {
  en: En,
  zh: Zh
};

export default languages;
