import demo from "@/pages/demo/z-routes";

let routes = [];
// 添加业务路由
routes = routes.concat(demo);

export default routes;
