const routes = [
  {
    path: "/",
    component: () => import("@/pages/demo/index")
  }
];

export default routes;
