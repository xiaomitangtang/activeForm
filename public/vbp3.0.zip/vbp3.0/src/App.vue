<template>
    <div id="app">
        <img src="./assets/logo.png">
        <swx-datepicker></swx-datepicker>
        <router-view/>
    </div>
</template>
<script>
export default {
  name: "app"
};
</script>
<style lang="less">
html,
body {
  width: 100%;
  height: 100%;
  margin: 0;
  padding: 0;
}
#app {
  font-family: "Avenir", Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  width: 100%;
  height: 100%;
  overflow: hidden;
  box-sizing: border-box;
}
</style>
