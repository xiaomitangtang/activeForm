## 指令相关文件夹说明 (directives)
- 功能
> 全局指令处理，只需要在此处使用`Vue.directive`即可扩展项目的指令集