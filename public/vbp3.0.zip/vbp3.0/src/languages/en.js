module.exports = {
  demo: {
    title:
      "This page can be deleted in the actual development, this example is used to manage page status using vuex demo",
    currentcode: "Current Code",
    precode: "Previous Code",
    changecode: "Change Code"
  }
};
