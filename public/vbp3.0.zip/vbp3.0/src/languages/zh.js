module.exports = {
  demo: {
    title: "该页面在实际开发可以删除，本例用于使用vuex管理页面状态的演示",
    currentcode: "当前编码",
    precode: "之前编码",
    changecode: "改编编码"
  }
};
